<?php
/***************************************
* HINDI NAME GENERATOR
* Version: 1.0
* FILE: index.php
* AUTHOR: Rahul Singh
* DATE: 09.06.2017
* DETAILS: GENERATE MILLIONS OF UNIQUE NAME IN ONE CLICK
***************************************/
 include('../config/class.config.php'); $girl=constant("GIRL"); include($girl); ?>
<title>Indian Hindi Girl Name Generator</title>
<script type="text/javascript">function refresh(){location.reload();}</script>
