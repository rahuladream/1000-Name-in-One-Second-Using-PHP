<?php
/***************************************
* HINDI NAME GENERATOR
* Version: 1.0
* FILE: class.config.php
* AUTHOR: Rahul Singh
* DATE: 09.06.2017
* DETAILS: GENERATE MILLIONS OF UNIQUE NAME IN ONE CLICK
***************************************/
session_start();
       $db_host='localhost';
       $db_user='root';
       $db_pass='';
       $db_name='indian-name-generator';
      DEFINE("BOY","../config/class.boy.php"); DEFINE("GIRL","../config/class.girl.php");
       try
       {
       	$db_conn = new PDO ("mysql:host={$db_host};dbname={$db_name}",$db_user,$db_pass);
       	$db_conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
       }
       catch(PDOException $e)
        {
            echo $e->getMessage();
       }
?>
