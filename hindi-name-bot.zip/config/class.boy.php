
<?php 
/***************************************
* HINDI NAME GENERATOR
* Version: 1.0
* FILE: index.php
* AUTHOR: Rahul Singh
* DATE: 09.06.2017
* DETAILS: GENERATE MILLIONS OF UNIQUE NAME IN ONE CLICK
***************************************/
if(empty($_GET['sinfo']) && empty($_GET['ninfo'])) { ?>
<?php $stmt = $db_conn->prepare("SELECT * FROM boy_name ORDER BY RAND() limit 1 "); $stmt2 = $db_conn->prepare("SELECT * FROM surname ORDER BY RAND() limit 1"); $stmt->execute();$stmt2->execute();if($stmt->rowCount()>0 && $stmt2->rowCount()> 0){   while($showName=$stmt->fetch(PDO::FETCH_ASSOC)) { while($surName=$stmt2->fetch(PDO::FETCH_ASSOC)) { ?> 
<br/><h3> Indian Hindi Girl Name </h3><br/><font size="5"><a href="?ninfo=<?php echo $showName['Name']; ?>" target="_blank"><?php echo $showName['Name']; ?> <?php echo $surName['Surname']; ?></a></font>
<br/><br/><button onclick="refresh()"> Reload New Name </button> 
  <?php } } } else { ?> <h3> We could find Anything </h3><br/> <a href="./"> Go Home </a> <?php } ?>      
<?php } else { ?>
<?php $sinfo=$_GET['ninfo']; $stmt = $db_conn->prepare("SELECT * FROM boy_name WHERE Name=:sname "); $stmt->execute(array(":sname"=>$sinfo)); $stmt->execute(); if($stmt->rowCount()>0){ while($infoName=$stmt->fetch(PDO::FETCH_ASSOC))
 {  ?> <br/><h3> Meaning of Name : <br/></h3><font size="5" color="green"><?php echo $infoName['Meaning']; ?> </font>
<br/><h4></h4><br/>
  <?php } } else {  ?>  <h3> We could find Anything </h3><br/> <a href="./"> Go Home </a><?php } ?>
<?php } ?>